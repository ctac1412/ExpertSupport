// document.querySelector('.wrapper').innerHTML += '<label for"mybar">Мой бар</label><div id="mybar" data-preset="stripe" class="ldBar label-center" data-value="50"></div>'
